<?php

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));
    $confirm_password = htmlspecialchars(trim($_POST['confirm-password']));
    $signup_type = $_POST['signup_type'];

    // if passwords match
    if ($password !== $confirm_password) {
        if ($signup_type == 'investor') {
            header("Location: signup-investor.php?error=passwords_mismatch");
        } else {
            header("Location: signup-business.php?error=passwords_mismatch");
        }
        exit();
    }

    if ($signup_type == 'investor') {
        // if email already exists in Investor table
        $sql_check = "SELECT Email FROM Investor WHERE Email = :email";
        $stmt_check = $mysql->prepare($sql_check);
        $stmt_check->bindParam(':email', $email);
        $stmt_check->execute();
        if ($stmt_check->rowCount() > 0) {
            header("Location: signup-investor.php?error=email_exists");
            exit();
        }

        // insert a new investor
        $sql_insert = "INSERT INTO Investor (Email, Password) VALUES (:email, :password)";
        $stmt_insert = $mysql->prepare($sql_insert);
        $stmt_insert->bindParam(':email', $email);
        $stmt_insert->bindParam(':password', $hashed_password);

        if ($stmt_insert->execute()) {
            header("Location: signup-investor.php?signup_success=true");
            exit();
        } else {
            header("Location: signup-investor.php?error=db_error");
            exit();
        }
    } elseif ($signup_type == 'business') {
        // if email already exists in Business table
        $sql_check = "SELECT Email FROM Business WHERE Email = :email";
        $stmt_check = $mysql->prepare($sql_check);
        $stmt_check->bindParam(':email', $email);
        $stmt_check->execute();
        if ($stmt_check->rowCount() > 0) {
            header("Location: signup-business.php?error=email_exists");
            exit();
        }

        // insert a new business owner
        $sql_insert = "INSERT INTO Business (Email, Password) VALUES (:email, :password)";
        $stmt_insert = $mysql->prepare($sql_insert);
        $stmt_insert->bindParam(':email', $email);
        $stmt_insert->bindParam(':password', $hashed_password);

        if ($stmt_insert->execute()) {
            header("Location: signup-business.php?signup_success=true");
            exit();
        } else {
            header("Location: signup-business.php?error=db_error");
            exit();
        }
    }
} else {
    // if the request is not a POST request
    header("Location: /login/login.php");
    exit();
}
?>
