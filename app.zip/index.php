<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fundify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="footer.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>
    <div id="navbar-placeholder"></div>
    <main class="hero">
        <div class="hero-bg bg1"></div>
        <div class="hero-bg bg2"></div>

        <div class="hero-overlay">
            <h1>Empowering Small Businesses, Connecting Investors</h1>
            <p>A crowdfunding platform where businesses share ideas and investors support them.</p>
            <div class="hero-button">
                <button onclick="window.location.href='/login/login-business.php'">Get Started as Business</button>
                <button onclick="window.location.href='/login/login-investor.php'">Get Started as Investor</button>
            </div>
        </div>
    </main>

    <div id="footer-placeholder"></div>

</body>

<script src="load-navbar.js"></script>
<script src="load-footer.js"></script>
<script src="Script.js"></script>

</html>
