document.querySelectorAll('.more-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
        window.location.href = 'investor_pitch_details.html'; // Change path as needed
    });
});
